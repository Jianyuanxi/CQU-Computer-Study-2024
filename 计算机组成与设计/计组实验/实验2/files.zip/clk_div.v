`timescale 1ns / 1ps
// 时钟分频器 —— 将100MHz板载时钟分频至1Hz
// 100_000_000 / 2 = 50_000_000 个半周期计数
module clk_div(
    input  hclk,   // 100MHz板载时钟
    input  rst,
    output reg lclk    // 1Hz输出时钟
);
    reg [26:0] cnt;

    always @(posedge hclk) begin
        if (rst) begin
            cnt  <= 27'd0;
            lclk <= 1'b0;
        end else if (cnt == 27'd49_999_999) begin
            cnt  <= 27'd0;
            lclk <= ~lclk;
        end else begin
            cnt <= cnt + 1'b1;
        end
    end
endmodule
