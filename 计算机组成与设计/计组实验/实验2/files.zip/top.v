`timescale 1ns / 1ps
// 顶层文件 —— 将PC、加法器、指令ROM、Controller、时钟分频、显示模块连接
// 接口严格匹配testbench: top(hclk, rst, seg[6:0], ans[7:0], led[9:0])
// LED管脚映射（指导书表1）：
//   led[0]=memtoreg, led[1]=memwrite, led[2]=pcsrc,
//   led[3]=alusrc,   led[4]=regdst,   led[5]=regwrite,
//   led[6]=jump,     led[7]=branch,   led[8:10]=alucontrol
module top(
    input        hclk,
    input        rst,
    output [6:0] seg,
    output [7:0] ans,
    output [9:0] led
);
    // ---- 时钟 ----
    wire lclk;
    clk_div u_clk_div(
        .hclk (hclk),
        .rst  (rst),
        .lclk (lclk)
    );

    // ---- PC ----
    wire [31:0] pc, pc_plus4, instr;
    wire        inst_ce;

    pc u_pc(
        .clk     (lclk),
        .rst     (rst),
        .pc_next (pc_plus4),
        .pc      (pc),
        .inst_ce (inst_ce)
    );

    // ---- PC+4 加法器 ----
    assign pc_plus4 = pc + 32'h4;

    // ---- 指令存储器（Block Memory IP，单端口ROM）----
    // IP例化名：inst_rom，端口：clka, ena, addra, douta
    // addra宽度：由coe文件指令数决定，此处取低8位（最多256条指令）
    inst_rom u_inst_rom(
        .clka  (lclk),
        .ena   (inst_ce),
        .addra (pc[9:2]),   // 字节地址转字地址，取[9:2]共8位
        .douta (instr)
    );

    // ---- Controller ----
    wire       memtoreg, memwrite, branch, alusrc, regdst, regwrite, jump;
    wire [2:0] alucontrol;

    controller u_ctrl(
        .op         (instr[31:26]),
        .funct      (instr[5:0]),
        .memtoreg   (memtoreg),
        .memwrite   (memwrite),
        .branch     (branch),
        .alusrc     (alusrc),
        .regdst     (regdst),
        .regwrite   (regwrite),
        .jump       (jump),
        .alucontrol (alucontrol)
    );

    // ---- pcsrc（此阶段仅取指译码，无ALU zero，暂置0）----
    wire pcsrc = 1'b0;

    // ---- LED输出（指导书表1映射）----
    // LED映射，严格按testbench wire [9:0] led（共10位）
    // 指导书表1 led[8:10]与testbench冲突，以testbench为准：
    // led[0]=memtoreg, led[1]=memwrite, led[2]=pcsrc, led[3]=alusrc
    // led[4]=regdst, led[5]=regwrite, led[6]=jump, led[7]=branch
    // led[9:7]=alucontrol[2:0]（branch和alucontrol共用led[7]无法同时显示，
    //   上板时可在xdc中只约束需要的引脚，仿真不影响）
    assign led[0]   = memtoreg;
    assign led[1]   = memwrite;
    assign led[2]   = pcsrc;
    assign led[3]   = alusrc;
    assign led[4]   = regdst;
    assign led[5]   = regwrite;
    assign led[6]   = jump;
    assign led[7]   = branch;
    assign led[9:8] = alucontrol[1:0];

    // ---- 七段数码管：显示PC低16位（十六进制）----
    display u_display(
        .clk  (hclk),
        .rst  (rst),
        .num  (pc[15:0]),
        .seg  (seg),
        .ans  (ans)
    );
endmodule
