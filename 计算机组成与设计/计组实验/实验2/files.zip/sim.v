`timescale 1ns / 1ps
// Testbench —— 按指导书要求：时钟10ns，每周期打印指令及控制信号
// 打印格式: instruction: 32'hXXXXXXXX, memtoreg: X, memwrite: X, ...
module test_bench();

    reg  rst;
    reg  clk;
    wire [7:0] ans;
    wire [6:0] seg;
    wire [9:0] led;

    // 实例化DUT（接口与提供的testbench完全一致）
    top top(
        .hclk (clk),
        .rst  (rst),
        .seg  (seg),
        .ans  (ans),
        .led  (led)
    );

    // 时钟：周期20ns（10ns半周期）
    initial clk = 1'b0;
    always #10 clk = ~clk;

    // 复位并运行
    initial begin
        rst = 1'b1;
        #500;
        rst = 1'b0;
    end

    // 每个上升沿打印一次（复位释放后）
    // 直接观察顶层内部信号（仿真用层次路径）
    always @(posedge top.lclk) begin
        if (!rst) begin
            $display("instruction: 32'h%08h, memtoreg: %b, memwrite: %b, pcsrc: %b, alusrc: %b, regdst: %b, regwrite: %b, jump: %b, branch: %b, alucontrol: %b",
                top.instr,
                top.memtoreg,
                top.memwrite,
                top.pcsrc,
                top.alusrc,
                top.regdst,
                top.regwrite,
                top.jump,
                top.branch,
                top.alucontrol
            );
        end
    end

    // 运行足够周期后结束
    initial begin
        #100000;
        $finish;
    end

endmodule
